from flask import Flask, request, jsonify
from flask_cors import CORS

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import cosine_similarity
from random import sample
from json import loads

def create_app():
    app = Flask(__name__)
    cors = CORS()
    cors.init_app(app)
    return app

app = create_app()

def load_data():
    df = pd.read_csv('imdb_top_1000.csv', header=0)

    #Assuring that features are the right dtypes and dropping Nas------------------------------------------------------------------------------------------------
    df['Released_Year'] = pd.Series(list(x if x.isnumeric() else np.nan for x in df['Released_Year']))
    df['Runtime'] = pd.Series(list(x.split()[0] if x.split()[0].isnumeric() else np.nan for x in df['Runtime']))
    df['Released_Year'] = df['Released_Year'].astype(float)
    df['Runtime'] = df['Runtime'].astype(float)
    df['Gross'] = pd.Series(list(x if isinstance(x, float) else float(x.replace(',', '')) for x in df['Gross']))
    df = df.dropna(axis=0)

    #Standardization and Adding Other Features--------------------------------------------------------------------------------------------------------------------
    st = ['Released_Year', 'Runtime', 'No_of_Votes', 'Gross', 'IMDB_Rating']
    scaler = StandardScaler().fit(df[st])
    df_genre = df['Genre'].str.replace(',','|').str.replace(' ','').str.get_dummies()[['Action', 'Adventure', 'Horror', 'Romance', 'Sci-Fi', 'Drama', 'Comedy', 'Family', 'Animation']]
    df_rest = df[['Poster_Link', 'Series_Title']]
    df_final = pd.merge(df_rest, df_genre, left_index=True, right_index=True)
    df_final[st] = scaler.transform(df[st])
    df_final.reset_index(drop=True)
    return df_final

#Examplary Search Algorithm for the perfect Match------------------------------------------------------------------------------------------------------------
df_init = load_data()
df = df_init.copy()

#Searches for the pair with the highest heterogenity in a specific feature while maintaining the highest possible homogenity when looking at other features.
#We do this so we get the most information possible out of a question. For example, the algorithm will pick two movies that are very similar in genre, gross, No_of_Votes etc. but drastically different
#considering the Release Year. For that reason, we can assume that the customer is in the mood for a newer movie, if he chooses the modern one.

def questions(column):
    css = np.round(cosine_similarity(df.loc[:, ~df.columns.isin(['Poster_Link', 'Series_Title', column])]), 15)
    css = np.where(css < 0, 0, css)
    css = np.where(css == 1, 0, css)
    difference = [[abs(a-b) for a in df[column]] for b in df[column]]
    value = np.multiply(css, difference)
    index = np.argwhere(value == np.max(value))
    if df.iloc[index[0][0]][column] > df.iloc[index[0][1]][column]:
        return df.iloc[index[0][0]][['Series_Title', "Poster_Link"]], df.iloc[index[0][1]][['Series_Title', "Poster_Link"]]
    else:
        return df.iloc[index[0][1]][['Series_Title', "Poster_Link"]], df.iloc[index[0][0]][['Series_Title', "Poster_Link"]]

#Gets Films that represent the genres (we tried going for only the most popular ones, but it actually worsens the recommendations)
def get_representative_film_from_genre(genre):
    global df
    films = df[df[genre] == 1]
    item = sample(films[["Series_Title", "Poster_Link"]].iloc[:6].values.tolist(), 1)[0]
    df = df[df["Series_Title"] != item[0]]
    return item

#Compares the different genres iteratively, until we can narrow the dataset down on just one category
def genre_ranking(arr):
    res = list()
    while True:
        for i in range(0, len(arr) - 1, 2):
            if input(f"{get_representative_film_from_genre(arr[i])} > {get_representative_film_from_genre(arr[i + 1])}") == "Y":
                res.append(arr[i])
            else:
                res.append(arr[i + 1])
        if len(res) > 1 or len(arr) == 3:
            if len(arr) % 2 == 1:
                res.append(arr[-1])
            arr, res = res, list()
        else:
            break
    return res[0]

#Lets the User decide between two films, then uses only the 50% of the data that were above/below the median (depending on the decision).
def decision(column, choice): 
    global df
    if choice == 0:
        df = df[df[column] > df[column].median()]
    elif choice == 1:
        df = df[df[column] < df[column].median()]

@app.route("/", methods = ["POST"])
def api():
    global df
    try:
        info = request.get_json()
        print(info)

        if info["type"] == "genre":
            if info["reset"]:
                df = df_init.copy()
            film_1 = get_representative_film_from_genre(info["genre_1"])
            film_2 = get_representative_film_from_genre(info["genre_2"])
            return jsonify(film_1 = film_1, film_2 = film_2), 200
        elif info["type"] == "animation":
            df = df[(df[info["genre"]] == 1)]
            print(df)
            aquestions1, aquestions2 = questions('Animation')
            return jsonify(film_1 = [aquestions1[0], aquestions1[1]], film_2 = [aquestions2[0], aquestions2[1]]), 200
        elif info["type"] == "year":
            rquestions1, rquestions2 = questions('Released_Year')
            decision("Animation", info["choice"])
            return jsonify(film_1 = [rquestions1[0], rquestions1[1]], film_2 = [rquestions2[0], rquestions2[1]]), 200
        elif info["type"] == "gross":
            gquestions1, gquestions2 = questions('Gross')
            decision("Released_Year", info["choice"])
            return jsonify(film_1 = [rquestions1[0], rquestions1[1]], film_2 = [rquestions2[0], rquestions2[1]]), 200
        elif info["type"] == "result":
            decision("Gross", info["choice"])
            return jsonify(**loads(df.sort_values(by = 'IMDB_Rating', ascending = False).head(3)[['Poster_Link', 'Series_Title']].to_json())), 200
    except Exception:
        import traceback
        traceback.print_exc()
        raise

if __name__ == "__main__":
    app.run(debug = True)
