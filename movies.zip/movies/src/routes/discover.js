import React from 'react';
import { useState, useEffect } from "react";

import './discover.css';

let genres = [
    "Action",
    "Adventure",
    "Comedy",
    "Drama",
    "Family",
    "Horror",
    "Romance",
    "Sci-Fi"
];

export default function Discover() {
    const [question, setQuestion] = useState({});
    useEffect(() => {
        fetch('http://localhost:5000/',{
            method:'POST',
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type':'application/json'
            },
            body: JSON.stringify({
                reset: true,
                type: "genre",
                genre_1: genres[0],
                genre_2: genres[1]
            })
        })
        .then(resp => resp.json())
        .then(resp => {
            setQuestion({
                genres: [...genres],
                index: 1,
                choice_1: resp.film_1[0],//genres[0],//get_representative_film_from_genre(genres[0]),
                choice_2: resp.film_2[0],//genres[1],//get_representative_film_from_genre(genres[1]),
                img_1: resp.film_1[1],
                img_2: resp.film_2[1],
                state: "genre"
            });
        })
        .catch(error => console.log(error));
    },[]);

    function updateQuestion(result_index_offset) {
        if(question.state === "end") {
            updateEnd(result_index_offset);
        } else if(question.state === "gross") {
            updateGross(result_index_offset);
        } else if(question.state === "year") {
            updateYear(result_index_offset);
        } else if(question.state === "animation") {
            updateAnim(result_index_offset);
        } else if(question.state === "genre") {
            updateGenre(result_index_offset);
        }
    }

    function updateAnim(result_index_offset) {
        console.log(result_index_offset);
        console.log(question);
        fetch('http://localhost:5000/',{
            method:'POST',
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type':'application/json'
            },
            body: JSON.stringify({
                type: "animation",
                genre: question.genre,
                reset: false,
                choice: result_index_offset
            })
        })
        .then(resp => resp.json())
        .then(resp => {
            setQuestion({
                choice_1: resp.film_1[0],//question.results[0],//get_representative_film_from_genre(question.results[0]),
                choice_2: resp.film_2[0],//question.results[1],//get_representative_film_from_genre(question.results[1]),
                img_1: resp.film_1[1],
                img_2: resp.film_2[1],
                state: "year"
            });
        });
    }

    function updateYear(result_index_offset) {
        console.log(result_index_offset);
        console.log(question);
        fetch('http://localhost:5000/',{
            method:'POST',
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type':'application/json'
            },
            body: JSON.stringify({
                type: "year",
                reset: false,
                choice: result_index_offset
            })
        })
        .then(resp => resp.json())
        .then(resp => {
            setQuestion({
                choice_1: resp.film_1[0],//question.results[0],//get_representative_film_from_genre(question.results[0]),
                choice_2: resp.film_2[0],//question.results[1],//get_representative_film_from_genre(question.results[1]),
                img_1: resp.film_1[1],
                img_2: resp.film_2[1],
                state: "gross"
            });
        });
    }

    function updateGross(result_index_offset) {
        console.log(result_index_offset);
        console.log(question);
        fetch('http://localhost:5000/',{
            method:'POST',
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type':'application/json'
            },
            body: JSON.stringify({
                type: "gross",
                reset: false,
                choice: result_index_offset
            })
        })
        .then(resp => resp.json())
        .then(resp => {
            setQuestion({
                choice_1: resp.film_1[0],//question.results[0],//get_representative_film_from_genre(question.results[0]),
                choice_2: resp.film_2[0],//question.results[1],//get_representative_film_from_genre(question.results[1]),
                img_1: resp.film_1[1],
                img_2: resp.film_2[1],
                state: "end"
            });
        });
    }

    function updateEnd(result_index_offset) {

    }

    function updateGenre(result_index_offset) {
        if(question.index >= question.genres.length - 1) {
            fetch('http://localhost:5000/',{
                method:'POST',
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type':'application/json'
                },
                body: JSON.stringify({
                    type: "animation",
                    reset: false,
                    genre: question.genres[question.genres.length - 1]
                })
            })
            .then(resp => resp.json())
            .then(resp => {
                console.log(resp);
                setQuestion({
                    choice_1: resp.film_1[0],//question.results[0],//get_representative_film_from_genre(question.results[0]),
                    choice_2: resp.film_2[0],//question.results[1],//get_representative_film_from_genre(question.results[1]),
                    img_1: resp.film_1[1],
                    img_2: resp.film_2[1],
                    genre: question.genre,
                    state: "animation"
                });
            });
            console.log("Anim");
        } else {
            setQuestion({
                genres: question.genres,
                index: question.index,
                choice_1: question.choice_1,//genres[question.index + 2],//get_representative_film_from_genre(genres[question.index]),
                choice_2: question.choice_2,//genres[question.index + 3],//get_representative_film_from_genre(genres[question.index + 1]),
                img_1: question.img_1,
                img_2: question.img_2,
                state: "genre"
            });
            fetch('http://localhost:5000/',{
                method:'POST',
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type':'application/json'
                },
                body: JSON.stringify({
                    type: "genre",
                    reset: false,
                    genre_1: genres[question.index],
                    genre_2: genres[question.index + 1]
                })
            })
            .then(resp => resp.json())
            .then(resp => {
                console.log(question);
                let agenres = question.genres;
                if(!!result_index_offset) {
                    let genre_i = question.genres[question.index];
                    let genre_im = question.genres[question.index - 1];
                    agenres[question.index - 1] = genre_i;
                    agenres[question.index] = genre_im;
                }
                setQuestion({
                    genres: agenres,
                    index: question.index + 1,
                    choice_1: resp.film_1[0],//genres[question.index + 2],//get_representative_film_from_genre(genres[question.index]),
                    choice_2: resp.film_2[0],//genres[question.index + 3],//get_representative_film_from_genre(genres[question.index + 1]),
                    img_1: resp.film_1[1],
                    img_2: resp.film_2[1],
                    state: "genre"
                });
            });
        }
    }

    return (
        <div className="container">
            <div className="back">BACK</div>
            <div className="questionText">What would you rather watch right now?</div>
            <div className="subContainer">
                <button onClick={() => updateQuestion(0)}>
                    <div className="q">{question.choice_1}</div>
                    <img src={question.img_1} alt="" className="questionImg"></img>
                </button>
                <div className="vs">VS</div>
                <button onClick={() => updateQuestion(1)}>
                    <div className="q">{question.choice_2}</div>
                    <img src={question.img_2} alt="" className="questionImg"></img>
                </button>
            </div>
        </div>
    )
}