import React from 'react';

import { Link } from 'react-router-dom';

import './home.css';

import play from './assets/play.png';
import search from './assets/search.png';
import avengers from './assets/avengers.jpg';
import brave from './assets/brave.jpg';
import doctor_who from './assets/doctor_who.jpg';
import black_panther from './assets/black_panther.jpg';

export function Home() {
    return (
        <div className="container">
            <header className="nav">
                <div className="navitem">Home</div>
                <div className="navitem">Movies</div>
                <div className="navitem">TV Shows</div>
                <div className="navitem">Videos</div>
                <div className="navitem">FAQ</div>
                <div className="navitem">Pricing</div>
                <div className="navitem">Contact us</div>
                <div className="navitem"><img src={search} alt="Search" className="search"></img></div>
                <div className="navitem">Max Mueller</div>
            </header>
            <div className="bigText">
                Welome back, Max Mueller
            </div>
            <div className="bigText">
                Meet Sunrise Discovery
            </div>
            <div className="smallText">
                Don't know what to watch?
            </div>
            <div className="smallText">
                Try Sunrise Discovery to find the perfect match
            </div>
            <Link to="/discover" className="discover">
                <img src={play} alt="Discover" className="play"></img>
            </Link>
            <div className="movieContainer">
                <div className="movies">
                    New Movies
                </div>
                <img src={avengers} alt="Avengers" className="movie"></img>
                <img src={brave} alt="Brave" className="movie"></img>
                <img src={doctor_who} alt="Doctor Who" className="movie"></img>
                <img src={black_panther} alt="Black Panther" className="movie"></img>
            </div>
        </div>
    )
}